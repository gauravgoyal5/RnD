/* tslint:disable */
require("./HelloWorld.module.css");
const styles = {
  helloWorld: 'helloWorld_7661eada',
  container: 'container_7661eada',
  row: 'row_7661eada',
  column: 'column_7661eada',
  'ms-Grid': 'ms-Grid_7661eada',
  title: 'title_7661eada',
  subTitle: 'subTitle_7661eada',
  description: 'description_7661eada',
  button: 'button_7661eada',
  label: 'label_7661eada'
};

export default styles;
/* tslint:enable */