import * as React from 'react';
import styles from './HelloWorld.module.scss';
import { IHelloWorldProps } from './IHelloWorldProps';
import { escape } from '@microsoft/sp-lodash-subset';

import { Grid, GridColumn, GridExpandChangeEvent, GridDetailRow, GridToolbar, GridColumnProps } from '@progress/kendo-react-grid';
// import { process, State, DataResult } from '@progress/kendo-data-query';
import '@progress/kendo-theme-default/dist/all.css';


export default class HelloWorld extends React.Component<IHelloWorldProps, {}> {
  public render(): React.ReactElement<IHelloWorldProps> {
    return (
      <div className={ styles.helloWorld }>
        <div className={ styles.container }>
        <Grid
      style={{
        height: "400px",
      }}
      

      data={[]}
    >
      <GridColumn field="ProductName" title="Product Name" width="240px" />
      <GridColumn
        field="FirstOrderedOn"
        width="240px"
        filter="date"
        format="{0:d}"
      />
      <GridColumn field="UnitPrice" width="180px" filter="numeric" format="{0:c}" />
      <GridColumn field="Discontinued" width="190px" filter="boolean" />
      
    </Grid>
        </div>
      </div>
    );
  }
}
