export interface IHelloWorldProps {
    description: string;
}
//# sourceMappingURL=IHelloWorldProps.d.ts.map