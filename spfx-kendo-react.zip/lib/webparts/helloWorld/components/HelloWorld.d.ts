import * as React from 'react';
import { IHelloWorldProps } from './IHelloWorldProps';
import '@progress/kendo-theme-default/dist/all.css';
export default class HelloWorld extends React.Component<IHelloWorldProps, {}> {
    render(): React.ReactElement<IHelloWorldProps>;
}
//# sourceMappingURL=HelloWorld.d.ts.map